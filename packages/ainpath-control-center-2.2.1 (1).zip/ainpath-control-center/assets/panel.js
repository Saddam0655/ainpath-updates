document.addEventListener('click',function(e){if(document.body.classList.contains('ap-open')&&window.innerWidth<=820&&!e.target.closest('.ap-side')&&!e.target.closest('.ap-menu'))document.body.classList.remove('ap-open');});

document.addEventListener('DOMContentLoaded', function () {
  var ta = document.getElementById('ap-raw-text');
  var stats = document.getElementById('ap-text-stats');
  var file = document.getElementById('ap-raw-file');
  var fileStatus = document.getElementById('ap-file-status');

  function updateStats() {
    if (!ta || !stats) return;
    var chars = ta.value.length;
    var lines = ta.value ? ta.value.split(/\r?\n/).length : 0;
    stats.textContent = 'পেস্ট করা লেখা: ' + chars.toLocaleString() + ' অক্ষর · ' + lines.toLocaleString() + ' লাইন';
  }
  if (ta) {
    ta.addEventListener('input', updateStats);
    ta.addEventListener('paste', function () { setTimeout(updateStats, 0); });
    updateStats();
  }
  if (file) {
    file.addEventListener('change', function () {
      if (!fileStatus) return;
      if (!file.files || !file.files.length) { fileStatus.textContent = ''; return; }
      var f = file.files[0];
      fileStatus.textContent = 'নির্বাচিত ফাইল: ' + f.name + ' · ' + Math.max(1, Math.round(f.size / 1024)).toLocaleString() + ' KB';
    });
  }
});
