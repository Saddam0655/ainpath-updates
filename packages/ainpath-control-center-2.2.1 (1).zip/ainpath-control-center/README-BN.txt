AinPath Control Center 2.2.1

মূল সুবিধা
- আলাদা Control Center: /ainpath-admin/
- সম্পূর্ণ স্বতন্ত্র AinPath Login: /ainpath-login/
- AinPath username/password WordPress username/password থেকে আলাদা
- প্রথমবার শুধু site ownership যাচাই করে স্বতন্ত্র account তৈরি: /ainpath-setup/
- নিজস্ব secure session, HttpOnly cookie, CSRF protection ও login rate limit
- Dashboard, আইন/ধারা Manager, Smart Import, Import History
- TXT/MD file সরাসরি Analyze; মোবাইল Copy/Paste কেটে গেলেও পুরো ফাইল ব্যবহার করা যায়
- Smart Detect: [SECTION] বাধ্যতামূলক নয়
- Field & Rules Manager
- Master Validation
- Duplicate update/skip
- Backup/Restore JSON
- Module Manager
- Notifications Center
- Update Center
- দিনে দুইবার remote update check (WP-Cron)
- নতুন version এলে Control Center notification; optional email notification
- স্বতন্ত্র AinPath Panel থেকেই One-click Update Now
- optional Auto Update
- Login & Account page থেকে AinPath password পরিবর্তন
- MCQ Generator এই version-এ ইচ্ছাকৃতভাবে নেই; পরে আলাদা module হবে।

প্রথমবার Login Setup
1. Version 2.2.1 install/update করুন।
2. WordPress Dashboard > AinPath Control থেকে “স্বতন্ত্র AinPath Login তৈরি করুন” চাপুন।
3. নতুন AinPath username/password দিন। এটি WordPress credentials থেকে আলাদা থাকবে।
4. এরপর /ainpath-login/ দিয়েই AinPath Control Center ব্যবহার করুন।

একবারের Update Source Setup
1. AinPath Settings-এ স্থায়ী Update Manifest URL বসান।
2. নতুন version প্রকাশ হলে Notifications/Update Center-এ দেখা যাবে।
3. Update Now চাপলে AinPath package নিজে download/install করার চেষ্টা করবে।
4. Auto Update চালু করলে manual Update Now-ও লাগবে না।

Update Manifest sample
{
  "version": "2.3.0",
  "download_url": "https://example.com/ainpath-control-center-2.3.0.zip",
  "homepage": "https://example.com",
  "requires": "6.0",
  "tested": "6.8",
  "changelog": "নতুন সুবিধার বিবরণ"
}

গুরুত্বপূর্ণ
- স্বতন্ত্র Login তৈরির সময় WordPress admin শুধু site ownership যাচাইয়ের জন্য একবার ব্যবহার হয়; AinPath password/session WordPress user table-এ রাখা হয় না।
- Update notification পেতে Manifest URL-টি একটি স্থায়ী public URL হতে হবে।
- কিছু hosting-এ filesystem write permission না থাকলে One-click Update hosting-এর অনুমতি চাইতে পারে।
- Email notification server/hosting-এর mail delivery সক্ষমতার ওপর নির্ভর করে।
- পুরোনো AinPath Core পাশাপাশি চালানো যায়; data schema আলাদা হলে migration আলাদাভাবে করতে হবে।
