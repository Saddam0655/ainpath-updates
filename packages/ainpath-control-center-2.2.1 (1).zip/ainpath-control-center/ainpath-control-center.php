<?php
/**
 * Plugin Name: AinPath Control Center
 * Description: WordPress account থেকে আলাদা AinPath Login, নিজস্ব Admin Panel, Smart Section Importer, validation, modules, backup/restore, notification and remote update support.
 * Version: 2.2.1
 * Author: AinPath
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * Text Domain: ainpath-control-center
 */

if (!defined('ABSPATH')) exit;

final class AinPath_Control_Center {
    const VERSION = '2.2.1';
    const OPT_SETTINGS = 'ainpath_cc_settings';
    const OPT_FIELDS   = 'ainpath_cc_fields';
    const OPT_MODULES  = 'ainpath_cc_modules';
    const OPT_MASTER   = 'ainpath_cc_master_data';
    const OPT_RULES    = 'ainpath_cc_detection_rules';
    const CPT_SECTION  = 'ainpath_section';
    const QV_PANEL     = 'ainpath_panel';
    const QV_LOGIN     = 'ainpath_login';
    const QV_LOGOUT    = 'ainpath_logout';
    const QV_SETUP     = 'ainpath_setup';
    const AUTH_COOKIE  = 'ainpath_cc_session';
    const OPT_NOTICES  = 'ainpath_cc_notifications';
    const OPT_VERSION  = 'ainpath_cc_installed_version';
    const UPDATE_CRON  = 'ainpath_cc_update_check';

    private static $instance = null;

    public static function instance() {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('init', [$this, 'register_post_type']);
        add_action('init', [$this, 'add_rewrite']);
        add_filter('query_vars', [$this, 'query_vars']);
        add_action('template_redirect', [$this, 'panel_router'], 1);
        add_action('admin_menu', [$this, 'admin_menu']);
        add_action('admin_init', [$this, 'admin_redirect']);
        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_remote_update']);
        add_filter('plugins_api', [$this, 'plugin_info'], 20, 3);
        add_filter('auto_update_plugin', [$this, 'maybe_auto_update'], 10, 2);
        add_action(self::UPDATE_CRON, [$this, 'scheduled_update_check']);
        add_action('init', [$this, 'maybe_upgrade'], 99);
    }

    public static function activate() {
        self::instance()->register_post_type();
        self::instance()->add_rewrite();
        self::instance()->create_tables();
        self::instance()->seed_options();
        update_option(self::OPT_VERSION, self::VERSION, false);
        if (!wp_next_scheduled(self::UPDATE_CRON)) wp_schedule_event(time() + HOUR_IN_SECONDS, 'twicedaily', self::UPDATE_CRON);
        flush_rewrite_rules();
    }

    public static function deactivate() {
        $ts = wp_next_scheduled(self::UPDATE_CRON);
        if ($ts) wp_unschedule_event($ts, self::UPDATE_CRON);
        flush_rewrite_rules();
    }

    public function maybe_upgrade() {
        $installed = get_option(self::OPT_VERSION, '');
        if ($installed === self::VERSION) return;
        $this->seed_options();
        $this->create_tables();
        $this->add_rewrite();
        if (!wp_next_scheduled(self::UPDATE_CRON)) wp_schedule_event(time() + HOUR_IN_SECONDS, 'twicedaily', self::UPDATE_CRON);
        flush_rewrite_rules(false);
        update_option(self::OPT_VERSION, self::VERSION, false);
    }

    private function seed_options() {
        if (!get_option(self::OPT_SETTINGS)) {
            update_option(self::OPT_SETTINGS, [
                'panel_title' => 'AinPath Control Center',
                'default_law' => '',
                'duplicate_mode' => 'update',
                'auto_title_from_first_line' => 1,
                'master_autocorrect' => 0,
                'update_manifest_url' => '',
                'auto_update_plugin' => 0,
                'max_import_mb' => 10,
                'block_on_errors' => 0,
                'require_law' => 1,
                'require_title' => 1,
                'notification_email' => get_option('admin_email'),
                'email_update_notifications' => 1,
                'panel_update_notifications' => 1,
            ]);
        }
        if (!get_option(self::OPT_MODULES)) {
            update_option(self::OPT_MODULES, [
                'sections' => 1,
                'smart_import' => 1,
                'history' => 1,
                'fields_rules' => 1,
                'backup' => 1,
                'updates' => 1,
                'feature_packs' => 1,
                'mcq' => 0,
            ]);
        }
        if (!get_option(self::OPT_FIELDS)) {
            update_option(self::OPT_FIELDS, $this->default_fields());
        }
        if (!get_option(self::OPT_RULES)) {
            update_option(self::OPT_RULES, $this->default_rules());
        }
        if (get_option(self::OPT_NOTICES, null) === null) {
            update_option(self::OPT_NOTICES, [[
                'id'=>'welcome-2-2-0',
                'title'=>'AinPath Control Center প্রস্তুত',
                'message'=>'স্বতন্ত্র AinPath Login চালু হয়েছে। এটি WordPress username/password থেকে আলাদা। Notification Center ও Update Center আগের মতোই আছে।',
                'type'=>'info','version'=>self::VERSION,'created_at'=>current_time('mysql'),'read'=>0
            ]], false);
        }
    }

    private function default_fields() {
        return [
            'law' => ['label'=>'আইন','aliases'=>['আইন','আইনের নাম','law','act','code'],'enabled'=>1],
            'section_no' => ['label'=>'ধারা','aliases'=>['ধারা','সেকশন','section','sec'],'enabled'=>1],
            'title' => ['label'=>'শিরোনাম','aliases'=>['শিরোনাম','বিষয়','title','heading'],'enabled'=>1],
            'concept' => ['label'=>'মূল ধারণা','aliases'=>['মূল ধারণা','ধারণা','মূল কথা','concept'],'enabled'=>1],
            'explanation' => ['label'=>'সহজ ব্যাখ্যা','aliases'=>['সহজ ব্যাখ্যা','ব্যাখ্যা','explanation'],'enabled'=>1],
            'police_example' => ['label'=>'পুলিশি উদাহরণ','aliases'=>['পুলিশি উদাহরণ','উদাহরণ','police example'],'enabled'=>1],
            'punishment' => ['label'=>'শাস্তি','aliases'=>['শাস্তি','দণ্ড','punishment'],'enabled'=>1],
            'time_limit' => ['label'=>'সময়সীমা','aliases'=>['সময়সীমা','সময় সীমা','মেয়াদ','time limit'],'enabled'=>1],
            'revision' => ['label'=>'Revision Point','aliases'=>['revision point','revision','রিভিশন পয়েন্ট','মনে রাখুন'],'enabled'=>1],
            'amendment' => ['label'=>'সংশোধন','aliases'=>['সংশোধন','amendment'],'enabled'=>1],
            'details' => ['label'=>'বিস্তারিত','aliases'=>['বিস্তারিত','নোট','details','note'],'enabled'=>1],
        ];
    }

    private function default_rules() {
        return [
            'section_markers' => ['ধারা','সেকশন','section','sec'],
            'law_markers' => ['আইন','আইনের নাম','law','act','code'],
            'title_markers' => ['শিরোনাম','বিষয়','title','heading'],
            'law_heading_words' => ['আইন','বিধি','দণ্ডবিধি','কার্যবিধি','Act','Code'],
            'section_separators' => ['-', '–', '—', ':', '.', ')'],
            'ignore_prefixes' => [],
        ];
    }

    public function create_tables() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();

        $table = $wpdb->prefix . 'ainpath_import_logs';
        $sql = "CREATE TABLE $table (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            created_at DATETIME NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
            source_name VARCHAR(190) NOT NULL DEFAULT '',
            total_count INT NOT NULL DEFAULT 0,
            inserted_count INT NOT NULL DEFAULT 0,
            updated_count INT NOT NULL DEFAULT 0,
            skipped_count INT NOT NULL DEFAULT 0,
            error_count INT NOT NULL DEFAULT 0,
            summary LONGTEXT NULL,
            PRIMARY KEY  (id),
            KEY created_at (created_at)
        ) $charset;";
        dbDelta($sql);

        $users = $wpdb->prefix . 'ainpath_admin_users';
        $sql_users = "CREATE TABLE $users (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            username VARCHAR(80) NOT NULL,
            email VARCHAR(190) NOT NULL DEFAULT '',
            display_name VARCHAR(190) NOT NULL DEFAULT '',
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(40) NOT NULL DEFAULT 'owner',
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL,
            updated_at DATETIME NOT NULL,
            last_login_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY username (username),
            KEY email (email)
        ) $charset;";
        dbDelta($sql_users);

        $sessions = $wpdb->prefix . 'ainpath_admin_sessions';
        $sql_sessions = "CREATE TABLE $sessions (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT UNSIGNED NOT NULL,
            token_hash CHAR(64) NOT NULL,
            expires_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL,
            last_seen_at DATETIME NOT NULL,
            user_agent_hash CHAR(64) NOT NULL DEFAULT '',
            PRIMARY KEY (id),
            UNIQUE KEY token_hash (token_hash),
            KEY user_id (user_id),
            KEY expires_at (expires_at)
        ) $charset;";
        dbDelta($sql_sessions);
    }

    public function register_post_type() {
        register_post_type(self::CPT_SECTION, [
            'labels' => [
                'name' => 'আইন/ধারা',
                'singular_name' => 'ধারা',
            ],
            'public' => false,
            'show_ui' => false,
            'show_in_rest' => true,
            'supports' => ['title','editor'],
        ]);
    }

    public function add_rewrite() {
        add_rewrite_rule('^ainpath-admin/?$', 'index.php?' . self::QV_PANEL . '=1', 'top');
        add_rewrite_rule('^ainpath-login/?$', 'index.php?' . self::QV_LOGIN . '=1', 'top');
        add_rewrite_rule('^ainpath-logout/?$', 'index.php?' . self::QV_LOGOUT . '=1', 'top');
        add_rewrite_rule('^ainpath-setup/?$', 'index.php?' . self::QV_SETUP . '=1', 'top');
    }

    public function query_vars($vars) {
        $vars[] = self::QV_PANEL;
        $vars[] = self::QV_LOGIN;
        $vars[] = self::QV_LOGOUT;
        $vars[] = self::QV_SETUP;
        return $vars;
    }

    public function admin_menu() {
        add_menu_page('AinPath Control Center','AinPath Control','manage_options','ainpath-control-center',[$this,'admin_landing'],'dashicons-shield-alt',3);
    }

    public function admin_landing() {
        $panel = esc_url(home_url('/ainpath-admin/'));
        $setup = esc_url(home_url('/ainpath-setup/'));
        echo '<div class="wrap"><h1>AinPath Control Center</h1>';
        if (!$this->has_custom_users()) {
            echo '<p>প্রথমবারের জন্য একটি স্বতন্ত্র AinPath Login account তৈরি করুন। এই account WordPress user/password থেকে আলাদা থাকবে।</p><p><a class="button button-primary button-hero" href="'.$setup.'">স্বতন্ত্র AinPath Login তৈরি করুন</a></p>';
        } else {
            echo '<p>AinPath-এর স্বতন্ত্র Admin Panel খুলুন।</p><p><a class="button button-primary button-hero" href="'.$panel.'">AinPath Admin Panel খুলুন</a></p>';
        }
        echo '</div>';
    }

    public function admin_redirect() {
        // Keep normal WP admin available; no forced redirect.
    }

    private function panel_url($tab='dashboard', $args=[]) {
        $url = home_url('/ainpath-admin/');
        $args = array_merge(['tab'=>$tab], $args);
        return add_query_arg($args, $url);
    }

    private function modules() {
        return wp_parse_args(get_option(self::OPT_MODULES, []), [
            'sections'=>1,'smart_import'=>1,'history'=>1,'fields_rules'=>1,'backup'=>1,'updates'=>1,'feature_packs'=>1,'mcq'=>0
        ]);
    }

    private function settings() {
        return wp_parse_args(get_option(self::OPT_SETTINGS, []), [
            'panel_title'=>'AinPath Control Center','default_law'=>'','duplicate_mode'=>'update',
            'auto_title_from_first_line'=>1,'master_autocorrect'=>0,'update_manifest_url'=>'',
            'auto_update_plugin'=>0,'max_import_mb'=>10,'block_on_errors'=>0,'require_law'=>1,'require_title'=>1,
            'notification_email'=>get_option('admin_email'),'email_update_notifications'=>1,'panel_update_notifications'=>1
        ]);
    }

    private function auth_users_table() {
        global $wpdb;
        return $wpdb->prefix . 'ainpath_admin_users';
    }

    private function auth_sessions_table() {
        global $wpdb;
        return $wpdb->prefix . 'ainpath_admin_sessions';
    }

    private function has_custom_users() {
        global $wpdb;
        $table = $this->auth_users_table();
        return (int)$wpdb->get_var("SELECT COUNT(*) FROM $table WHERE is_active=1") > 0;
    }

    private function cookie_token() {
        if (empty($_COOKIE[self::AUTH_COOKIE])) return '';
        $token = preg_replace('/[^a-f0-9]/i', '', (string)$_COOKIE[self::AUTH_COOKIE]);
        return strlen($token) === 64 ? strtolower($token) : '';
    }

    private function current_custom_user() {
        static $cached = null;
        static $loaded = false;
        if ($loaded) return $cached;
        $loaded = true;
        $token = $this->cookie_token();
        if (!$token) return null;
        global $wpdb;
        $sessions = $this->auth_sessions_table();
        $users = $this->auth_users_table();
        $hash = hash('sha256', $token);
        $now = current_time('mysql', true);
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT u.*, s.id AS session_id, s.expires_at FROM $sessions s INNER JOIN $users u ON u.id=s.user_id WHERE s.token_hash=%s AND s.expires_at>%s AND u.is_active=1 LIMIT 1",
            $hash, $now
        ), ARRAY_A);
        if (!$row) {
            $this->expire_auth_cookie();
            return null;
        }
        $cached = $row;
        $wpdb->update($sessions, ['last_seen_at'=>$now], ['id'=>(int)$row['session_id']], ['%s'], ['%d']);
        return $cached;
    }

    private function current_custom_user_id() {
        $u = $this->current_custom_user();
        return $u ? (int)$u['id'] : 0;
    }

    private function set_auth_cookie($token, $expires) {
        $secure = is_ssl();
        setcookie(self::AUTH_COOKIE, $token, [
            'expires'=>$expires,
            'path'=>COOKIEPATH ?: '/',
            'domain'=>COOKIE_DOMAIN ?: '',
            'secure'=>$secure,
            'httponly'=>true,
            'samesite'=>'Lax',
        ]);
        $_COOKIE[self::AUTH_COOKIE] = $token;
    }

    private function expire_auth_cookie() {
        setcookie(self::AUTH_COOKIE, '', [
            'expires'=>time()-3600,
            'path'=>COOKIEPATH ?: '/',
            'domain'=>COOKIE_DOMAIN ?: '',
            'secure'=>is_ssl(),
            'httponly'=>true,
            'samesite'=>'Lax',
        ]);
        unset($_COOKIE[self::AUTH_COOKIE]);
    }

    private function create_custom_session($user_id, $remember=true) {
        global $wpdb;
        $token = bin2hex(random_bytes(32));
        $hash = hash('sha256', $token);
        $ttl = $remember ? 30 * DAY_IN_SECONDS : 12 * HOUR_IN_SECONDS;
        $expires = time() + $ttl;
        $now_gmt = current_time('mysql', true);
        $ua = isset($_SERVER['HTTP_USER_AGENT']) ? hash('sha256', (string)$_SERVER['HTTP_USER_AGENT']) : '';
        $wpdb->insert($this->auth_sessions_table(), [
            'user_id'=>(int)$user_id,
            'token_hash'=>$hash,
            'expires_at'=>gmdate('Y-m-d H:i:s', $expires),
            'created_at'=>$now_gmt,
            'last_seen_at'=>$now_gmt,
            'user_agent_hash'=>$ua,
        ], ['%d','%s','%s','%s','%s','%s']);
        $this->set_auth_cookie($token, $expires);
        return $token;
    }

    private function custom_logout() {
        $token = $this->cookie_token();
        if ($token) {
            global $wpdb;
            $wpdb->delete($this->auth_sessions_table(), ['token_hash'=>hash('sha256',$token)], ['%s']);
        }
        $this->expire_auth_cookie();
    }

    private function csrf_token($action='panel') {
        $token = $this->cookie_token();
        if (!$token) return '';
        return hash_hmac('sha256', $action, wp_salt('auth').'|'.$token);
    }

    private function verify_csrf($value, $action='panel') {
        $expected = $this->csrf_token($action);
        return $expected && is_string($value) && hash_equals($expected, $value);
    }

    private function login_form_token() {
        $token = bin2hex(random_bytes(24));
        set_transient('ainpath_login_form_' . hash('sha256',$token), 1, 20 * MINUTE_IN_SECONDS);
        return $token;
    }

    private function verify_login_form_token($token) {
        $token = preg_replace('/[^a-f0-9]/i','',(string)$token);
        if (strlen($token)!==48) return false;
        $key='ainpath_login_form_' . hash('sha256',$token);
        $ok=(bool)get_transient($key);
        delete_transient($key);
        return $ok;
    }

    private function login_rate_key($identity='') {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? (string)$_SERVER['REMOTE_ADDR'] : '';
        return 'ainpath_login_rate_' . hash('sha256', strtolower(trim($identity)).'|'.$ip);
    }

    private function login_rate_limited($identity='') {
        $data = get_transient($this->login_rate_key($identity));
        return is_array($data) && !empty($data['count']) && (int)$data['count'] >= 5;
    }

    private function record_login_failure($identity='') {
        $key=$this->login_rate_key($identity);
        $data=get_transient($key);
        $count=is_array($data)?(int)($data['count']??0):0;
        set_transient($key,['count'=>$count+1],15*MINUTE_IN_SECONDS);
    }

    private function clear_login_failures($identity='') {
        delete_transient($this->login_rate_key($identity));
    }

    private function login_url($args=[]) {
        return add_query_arg($args, home_url('/ainpath-login/'));
    }

    private function setup_url($args=[]) {
        return add_query_arg($args, home_url('/ainpath-setup/'));
    }

    public function panel_router() {
        if (get_query_var(self::QV_LOGOUT)) {
            $this->custom_logout();
            wp_safe_redirect($this->login_url(['logged_out'=>1]));
            exit;
        }

        if (get_query_var(self::QV_SETUP)) {
            $this->render_setup();
            exit;
        }

        if (get_query_var(self::QV_LOGIN)) {
            $this->render_login();
            exit;
        }

        if (!get_query_var(self::QV_PANEL)) return;

        if (!$this->has_custom_users()) {
            wp_safe_redirect($this->setup_url());
            exit;
        }
        if (!$this->current_custom_user()) {
            wp_safe_redirect($this->login_url(['redirect_to'=>$this->panel_url()]));
            exit;
        }

        $this->seed_options();
        $this->handle_actions();
        nocache_headers();
        status_header(200);
        $this->render_panel();
        exit;
    }

    private function render_setup() {
        $this->seed_options();
        if ($this->has_custom_users()) {
            wp_safe_redirect($this->login_url());
            exit;
        }
        if (!is_user_logged_in() || !current_user_can('manage_options')) {
            $target = home_url('/ainpath-setup/');
            wp_safe_redirect(wp_login_url($target));
            exit;
        }
        $error='';
        if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['ainpath_setup_action'])) {
            $nonce=sanitize_text_field(wp_unslash($_POST['_wpnonce']??''));
            if (!wp_verify_nonce($nonce,'ainpath_independent_setup')) {
                $error='Security check ব্যর্থ হয়েছে। আবার চেষ্টা করুন।';
            } else {
                $username=sanitize_user(wp_unslash($_POST['username']??''),true);
                $email=sanitize_email(wp_unslash($_POST['email']??''));
                $display=sanitize_text_field(wp_unslash($_POST['display_name']??'AinPath Admin'));
                $p1=(string)($_POST['password']??'');
                $p2=(string)($_POST['confirm_password']??'');
                if (strlen($username)<3) $error='Username কমপক্ষে ৩ অক্ষরের দিন।';
                elseif (strlen($p1)<10) $error='Password কমপক্ষে ১০ অক্ষরের দিন।';
                elseif ($p1!==$p2) $error='দুইবারের Password একই হয়নি।';
                else {
                    global $wpdb;
                    $ok=$wpdb->insert($this->auth_users_table(),[
                        'username'=>$username,'email'=>$email,'display_name'=>$display ?: $username,
                        'password_hash'=>password_hash($p1,PASSWORD_DEFAULT),'role'=>'owner','is_active'=>1,
                        'created_at'=>current_time('mysql',true),'updated_at'=>current_time('mysql',true)
                    ],['%s','%s','%s','%s','%s','%d','%s','%s']);
                    if (!$ok) $error='Account তৈরি করা যায়নি। Username অন্যটি দিন।';
                    else {
                        $uid=(int)$wpdb->insert_id;
                        $this->create_custom_session($uid,true);
                        $this->add_notification('independent-login-ready','স্বতন্ত্র Login চালু','AinPath Login এখন WordPress account থেকে সম্পূর্ণ আলাদা।','info',self::VERSION);
                        wp_safe_redirect($this->panel_url('account',['notice'=>'স্বতন্ত্র AinPath Login তৈরি হয়েছে।']));
                        exit;
                    }
                }
            }
        }
        nocache_headers(); status_header(200);
        $s=$this->settings(); $title=esc_html($s['panel_title']);
        echo '<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.$title.' Setup</title><link rel="stylesheet" href="'.esc_url(plugins_url('assets/panel.css',__FILE__)).'?v='.self::VERSION.'"></head><body class="ap-login-body">';
        echo '<div class="ap-login-card"><div class="ap-login-logo">🔐</div><h1>স্বতন্ত্র AinPath Login তৈরি করুন</h1><p>এটি একবারের setup। নতুন username/password WordPress-এর সাথে যুক্ত হবে না।</p>';
        if ($error) echo '<div class="ap-warning">'.esc_html($error).'</div>';
        echo '<form method="post" class="ap-form"><input type="hidden" name="ainpath_setup_action" value="1"><input type="hidden" name="_wpnonce" value="'.esc_attr(wp_create_nonce('ainpath_independent_setup')).'">';
        echo '<label>নাম<input name="display_name" value="AinPath Admin"></label><label>AinPath Username<input name="username" autocomplete="username" required></label><label>Email (ঐচ্ছিক)<input type="email" name="email"></label><label>নতুন Password<input type="password" name="password" minlength="10" autocomplete="new-password" required></label><label>Password আবার<input type="password" name="confirm_password" minlength="10" autocomplete="new-password" required></label><button class="ap-btn primary" type="submit">AinPath Login তৈরি করুন</button></form>';
        echo '<p class="ap-login-help">নিরাপত্তার জন্য শুধু প্রথম account তৈরির সময় WordPress administrator দিয়ে site ownership যাচাই করা হচ্ছে। Account তৈরি হওয়ার পর AinPath login/session আলাদা থাকবে।</p></div></body></html>';
    }

    private function render_login() {
        $this->seed_options();
        if (!$this->has_custom_users()) {
            wp_safe_redirect($this->setup_url());
            exit;
        }
        if ($this->current_custom_user()) {
            wp_safe_redirect($this->panel_url());
            exit;
        }
        $error='';
        if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['ainpath_login_action'])) {
            $identity=sanitize_text_field(wp_unslash($_POST['user_login']??''));
            if (!$this->verify_login_form_token($_POST['login_form_token']??'')) {
                $error='Security check ব্যর্থ হয়েছে। আবার চেষ্টা করুন।';
            } elseif ($this->login_rate_limited($identity)) {
                $error='অনেকবার ভুল Login চেষ্টা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন।';
            } else {
                global $wpdb;
                $table=$this->auth_users_table();
                $user=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE is_active=1 AND (username=%s OR email=%s) LIMIT 1",$identity,$identity),ARRAY_A);
                $password=(string)($_POST['user_password']??'');
                if (!$user || !password_verify($password,$user['password_hash'])) {
                    $this->record_login_failure($identity);
                    $error='AinPath Username/Email বা Password সঠিক নয়।';
                } else {
                    $this->clear_login_failures($identity);
                    if (password_needs_rehash($user['password_hash'],PASSWORD_DEFAULT)) {
                        $wpdb->update($table,['password_hash'=>password_hash($password,PASSWORD_DEFAULT),'updated_at'=>current_time('mysql',true)],['id'=>(int)$user['id']],['%s','%s'],['%d']);
                    }
                    $wpdb->update($table,['last_login_at'=>current_time('mysql',true)],['id'=>(int)$user['id']],['%s'],['%d']);
                    $this->create_custom_session((int)$user['id'],!empty($_POST['remember']));
                    $redirect=!empty($_POST['redirect_to'])?esc_url_raw(wp_unslash($_POST['redirect_to'])):$this->panel_url();
                    if (!$redirect || strpos($redirect,home_url())!==0) $redirect=$this->panel_url();
                    wp_safe_redirect($redirect); exit;
                }
            }
        }
        nocache_headers(); status_header(200);
        $s=$this->settings(); $title=esc_html($s['panel_title']);
        $redirect_to=isset($_GET['redirect_to'])?esc_url_raw(wp_unslash($_GET['redirect_to'])):$this->panel_url();
        $form_token=$this->login_form_token();
        echo '<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.$title.' Login</title><link rel="stylesheet" href="'.esc_url(plugins_url('assets/panel.css',__FILE__)).'?v='.self::VERSION.'"></head><body class="ap-login-body">';
        echo '<div class="ap-login-card"><div class="ap-login-logo">⚖️</div><h1>'.$title.'</h1><p>স্বতন্ত্র AinPath Admin Login</p>';
        if (!empty($_GET['logged_out'])) echo '<div class="ap-notice">সফলভাবে লগআউট হয়েছে।</div>';
        if ($error) echo '<div class="ap-warning">'.esc_html($error).'</div>';
        echo '<form method="post" class="ap-form"><input type="hidden" name="ainpath_login_action" value="1"><input type="hidden" name="login_form_token" value="'.esc_attr($form_token).'"><input type="hidden" name="redirect_to" value="'.esc_attr($redirect_to).'">';
        echo '<label>AinPath Username বা Email<input name="user_login" autocomplete="username" required></label><label>AinPath Password<input type="password" name="user_password" autocomplete="current-password" required></label><label class="check"><input type="checkbox" name="remember" value="1" checked>এই ডিভাইসে Login মনে রাখুন</label><button class="ap-btn primary" type="submit">AinPath Login</button></form>';
        echo '<p class="ap-login-help">এই account WordPress account থেকে আলাদা। WordPress username/password দিয়ে এখানে Login হবে না।</p></div></body></html>';
    }

    private function handle_actions() {
        $action = isset($_REQUEST['ainpath_action']) ? sanitize_key($_REQUEST['ainpath_action']) : '';
        if (!$action) return;

        if ($action === 'backup') {
            if (!$this->verify_csrf($_GET['ap_csrf'] ?? '', 'backup')) wp_die('Security check failed.');
            $payload = [
                'generated_at' => current_time('mysql'),
                'version' => self::VERSION,
                'settings' => get_option(self::OPT_SETTINGS, []),
                'fields' => get_option(self::OPT_FIELDS, []),
                'modules' => get_option(self::OPT_MODULES, []),
                'master' => get_option(self::OPT_MASTER, []),
                'sections' => $this->export_sections(),
            ];
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename=ainpath-backup-' . gmdate('Y-m-d-His') . '.json');
            echo wp_json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT);
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
        if (!$this->verify_csrf($_POST['ap_csrf'] ?? '', 'panel')) wp_die('Security check failed.');

        switch ($action) {
            case 'save_settings':
                $s = $this->settings();
                $s['panel_title'] = sanitize_text_field($_POST['panel_title'] ?? 'AinPath Control Center');
                $s['default_law'] = sanitize_text_field($_POST['default_law'] ?? '');
                $s['duplicate_mode'] = in_array(($_POST['duplicate_mode'] ?? 'update'), ['update','skip'], true) ? $_POST['duplicate_mode'] : 'update';
                $s['auto_title_from_first_line'] = !empty($_POST['auto_title_from_first_line']) ? 1 : 0;
                $s['master_autocorrect'] = !empty($_POST['master_autocorrect']) ? 1 : 0;
                $s['update_manifest_url'] = esc_url_raw($_POST['update_manifest_url'] ?? '');
                $s['auto_update_plugin'] = !empty($_POST['auto_update_plugin']) ? 1 : 0;
                $s['notification_email'] = sanitize_email($_POST['notification_email'] ?? get_option('admin_email'));
                $s['email_update_notifications'] = !empty($_POST['email_update_notifications']) ? 1 : 0;
                $s['panel_update_notifications'] = !empty($_POST['panel_update_notifications']) ? 1 : 0;
                update_option(self::OPT_SETTINGS, $s);
                delete_transient('ainpath_cc_remote_manifest');
                if (!wp_next_scheduled(self::UPDATE_CRON)) wp_schedule_event(time() + HOUR_IN_SECONDS, 'twicedaily', self::UPDATE_CRON);
                $this->redirect_notice('settings','সেটিংস সংরক্ষণ হয়েছে।');
                break;

            case 'save_modules':
                $m = $this->modules();
                foreach (array_keys($m) as $k) $m[$k] = !empty($_POST['modules'][$k]) ? 1 : 0;
                $m['mcq'] = 0; // Reserved for later separate module.
                update_option(self::OPT_MODULES, $m);
                $this->redirect_notice('modules','মডিউল সেটিংস সংরক্ষণ হয়েছে।');
                break;

            case 'save_fields':
                $fields = get_option(self::OPT_FIELDS, $this->default_fields());
                if (!empty($_POST['fields']) && is_array($_POST['fields'])) {
                    foreach ($_POST['fields'] as $key=>$f) {
                        if (!isset($fields[$key])) continue;
                        $fields[$key]['label'] = sanitize_text_field($f['label'] ?? $fields[$key]['label']);
                        $alias_text = sanitize_textarea_field($f['aliases'] ?? '');
                        $aliases = array_values(array_filter(array_map('trim', preg_split('/[,\n]+/u',$alias_text))));
                        if ($aliases) $fields[$key]['aliases'] = $aliases;
                        $fields[$key]['enabled'] = !empty($f['enabled']) ? 1 : 0;
                    }
                }
                if (!empty($_POST['new_field_label'])) {
                    $label = sanitize_text_field($_POST['new_field_label']);
                    $key = sanitize_key($_POST['new_field_key'] ?: sanitize_title($label));
                    if ($key && !isset($fields[$key])) {
                        $aliases = array_values(array_filter(array_map('trim', preg_split('/[,\n]+/u', sanitize_textarea_field($_POST['new_field_aliases'] ?? $label)))));
                        $fields[$key] = ['label'=>$label,'aliases'=>$aliases ?: [$label],'enabled'=>1,'custom'=>1];
                    }
                }
                update_option(self::OPT_FIELDS, $fields);
                $this->redirect_notice('fields','Field ও Rule সংরক্ষণ হয়েছে।');
                break;

            case 'preview_import':
                $raw = wp_unslash($_POST['raw_text'] ?? '');
                $source_name = 'paste';

                // Mobile-friendly full TXT/MD file import. File takes priority over pasted text.
                if (!empty($_FILES['raw_text_file']['name']) && isset($_FILES['raw_text_file']['tmp_name'])) {
                    $file = $_FILES['raw_text_file'];
                    if (!empty($file['error']) && (int)$file['error'] !== UPLOAD_ERR_OK) {
                        $this->redirect_notice('import','ফাইল আপলোড করা যায়নি। আবার চেষ্টা করুন।',['type'=>'error']);
                    }
                    $name = sanitize_file_name($file['name']);
                    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
                    if (!in_array($ext, ['txt','md'], true)) {
                        $this->redirect_notice('import','শুধু .txt বা .md ফাইল ব্যবহার করুন।',['type'=>'error']);
                    }
                    if (!empty($file['size']) && (int)$file['size'] > 5 * MB_IN_BYTES) {
                        $this->redirect_notice('import','ফাইলটি ৫ MB-এর বেশি। ছোট ভাগে দিন।',['type'=>'error']);
                    }
                    $contents = @file_get_contents($file['tmp_name']);
                    if ($contents === false || trim($contents) === '') {
                        $this->redirect_notice('import','ফাইলের লেখা পড়া যায়নি বা ফাইল খালি।',['type'=>'error']);
                    }
                    // Remove UTF-8 BOM if present.
                    $raw = preg_replace('/^\xEF\xBB\xBF/', '', $contents);
                    $source_name = $name;
                }

                if (trim($raw) === '') {
                    $this->redirect_notice('import','লেখা পেস্ট করুন অথবা একটি TXT ফাইল বেছে নিন।',['type'=>'error']);
                }

                $default_law = sanitize_text_field($_POST['import_default_law'] ?? '');
                $parsed = $this->parse_smart_text($raw, $default_law);
                $parsed['source_name'] = $source_name;
                $parsed['source_chars'] = function_exists('mb_strlen') ? mb_strlen($raw, 'UTF-8') : strlen($raw);
                $parsed['source_lines'] = substr_count(str_replace(["\r\n","\r"],"\n",$raw), "\n") + 1;
                set_transient('ainpath_preview_' . $this->current_custom_user_id(), $parsed, 30 * MINUTE_IN_SECONDS);
                $this->redirect_notice('import','Preview তৈরি হয়েছে।',['preview'=>1]);
                break;

            case 'confirm_import':
                $parsed = get_transient('ainpath_preview_' . $this->current_custom_user_id());
                if (!$parsed || empty($parsed['records'])) {
                    $this->redirect_notice('import','Preview পাওয়া যায়নি। আবার Analyze করুন।',['type'=>'error']);
                }
                $result = $this->import_records($parsed['records']);
                delete_transient('ainpath_preview_' . $this->current_custom_user_id());
                $msg = sprintf('Import সম্পন্ন: নতুন %d, আপডেট %d, বাদ %d, ত্রুটি %d।', $result['inserted'],$result['updated'],$result['skipped'],$result['errors']);
                $this->redirect_notice('import',$msg);
                break;

            case 'delete_section':
                $id = absint($_POST['section_id'] ?? 0);
                if ($id && get_post_type($id) === self::CPT_SECTION) wp_delete_post($id, true);
                $this->redirect_notice('sections','ধারাটি মুছে ফেলা হয়েছে।');
                break;

            case 'save_section':
                $id = absint($_POST['section_id'] ?? 0);
                $law = sanitize_text_field($_POST['law'] ?? '');
                $section_no = sanitize_text_field($_POST['section_no'] ?? '');
                $title = sanitize_text_field($_POST['title'] ?? '');
                $details = wp_kses_post($_POST['details'] ?? '');
                $postarr = ['post_type'=>self::CPT_SECTION,'post_status'=>'publish','post_title'=>$title ?: ('ধারা ' . $section_no),'post_content'=>$details];
                if ($id) $postarr['ID'] = $id;
                $id = wp_insert_post($postarr, true);
                if (!is_wp_error($id)) {
                    update_post_meta($id,'ap_law',$law);
                    update_post_meta($id,'ap_section_no',$this->normalize_digits($section_no));
                    update_post_meta($id,'ap_title',$title);
                    $fields = get_option(self::OPT_FIELDS, $this->default_fields());
                    foreach ($fields as $key=>$field) {
                        if (in_array($key,['law','section_no','title','details'],true)) continue;
                        $meta = 'ap_' . $key;
                        update_post_meta($id,$meta,wp_kses_post($_POST[$key] ?? ''));
                    }
                }
                $this->redirect_notice('sections','ধারাটি সংরক্ষণ হয়েছে।');
                break;

            case 'restore_backup':
                if (empty($_FILES['backup_file']['tmp_name'])) $this->redirect_notice('backup','Backup file নির্বাচন করা হয়নি।',['type'=>'error']);
                $json = file_get_contents($_FILES['backup_file']['tmp_name']);
                $data = json_decode($json, true);
                if (!is_array($data)) $this->redirect_notice('backup','Backup file সঠিক নয়।',['type'=>'error']);
                if (isset($data['settings'])) update_option(self::OPT_SETTINGS, $data['settings']);
                if (isset($data['fields'])) update_option(self::OPT_FIELDS, $data['fields']);
                if (isset($data['modules'])) update_option(self::OPT_MODULES, $data['modules']);
                if (isset($data['master'])) update_option(self::OPT_MASTER, $data['master']);
                if (!empty($data['sections']) && is_array($data['sections'])) $this->import_records($data['sections'], true);
                $this->redirect_notice('backup','Backup Restore সম্পন্ন হয়েছে।');
                break;

            case 'save_master':
                $raw = wp_unslash($_POST['master_json'] ?? '');
                $data = json_decode($raw, true);
                if (!is_array($data)) $this->redirect_notice('master','Master JSON সঠিক নয়।',['type'=>'error']);
                update_option(self::OPT_MASTER, $data);
                $this->redirect_notice('master','Master validation data সংরক্ষণ হয়েছে।');
                break;


            case 'install_update_now':
                $manifest = $this->remote_manifest(true);
                if (is_wp_error($manifest)) $this->redirect_notice('updates','Update source থেকে package পাওয়া যায়নি।',['type'=>'error']);
                if (empty($manifest['version']) || version_compare(self::VERSION, sanitize_text_field($manifest['version']), '>=')) {
                    $this->redirect_notice('updates','নতুন Version পাওয়া যায়নি।');
                }
                delete_site_transient('update_plugins');
                wp_update_plugins();
                require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
                $skin = new Automatic_Upgrader_Skin();
                $upgrader = new Plugin_Upgrader($skin);
                $result = $upgrader->upgrade(plugin_basename(__FILE__));
                if (is_wp_error($result) || !$result) {
                    $msg = is_wp_error($result) ? $result->get_error_message() : 'Hosting filesystem update অনুমতি দেয়নি।';
                    $this->redirect_notice('updates','Update করা যায়নি: '.$msg,['type'=>'error']);
                }
                wp_safe_redirect(home_url('/ainpath-admin/?tab=updates&notice='.rawurlencode('AinPath Update সম্পন্ন হয়েছে।')));
                exit;

            case 'check_updates_now':
                $result = $this->check_for_updates(true);
                delete_site_transient('update_plugins');
                wp_update_plugins();
                if (($result['status'] ?? '') === 'no_source') {
                    $this->redirect_notice('updates','Update source এখনো সেট করা হয়নি। Settings-এ Update Manifest URL দিন।',['type'=>'error']);
                }
                if (($result['status'] ?? '') === 'error') {
                    $this->redirect_notice('updates','Update server-এর সাথে যোগাযোগ করা যায়নি। পরে আবার চেষ্টা করুন।',['type'=>'error']);
                }
                if (($result['status'] ?? '') === 'update') {
                    $this->redirect_notice('updates','নতুন Version '.$result['version'].' পাওয়া গেছে। Notifications দেখুন।');
                }
                $this->redirect_notice('updates','আপনার AinPath Control Center আপডেটেড আছে।');
                break;

            case 'mark_all_notifications_read':
                $items = $this->notifications();
                foreach ($items as &$item) $item['read'] = 1;
                unset($item);
                update_option(self::OPT_NOTICES, $items, false);
                $this->redirect_notice('notifications','সব Notification পড়া হিসেবে চিহ্নিত হয়েছে।');
                break;

            case 'change_password':
                $user = $this->current_custom_user();
                $current = (string)($_POST['current_password'] ?? '');
                $new1 = (string)($_POST['new_password'] ?? '');
                $new2 = (string)($_POST['confirm_password'] ?? '');
                if (!$user || !password_verify($current, $user['password_hash'])) {
                    $this->redirect_notice('account','বর্তমান AinPath Password সঠিক নয়।',['type'=>'error']);
                }
                if (strlen($new1) < 10) $this->redirect_notice('account','নতুন Password কমপক্ষে ১০ অক্ষরের দিন।',['type'=>'error']);
                if ($new1 !== $new2) $this->redirect_notice('account','নতুন Password দুইবার একই হয়নি।',['type'=>'error']);
                global $wpdb;
                $wpdb->update($this->auth_users_table(),[
                    'password_hash'=>password_hash($new1,PASSWORD_DEFAULT),
                    'updated_at'=>current_time('mysql',true)
                ],['id'=>(int)$user['id']],['%s','%s'],['%d']);
                $token=$this->cookie_token();
                $hash=$token?hash('sha256',$token):'';
                if ($hash) {
                    $wpdb->query($wpdb->prepare("DELETE FROM {$this->auth_sessions_table()} WHERE user_id=%d AND token_hash<>%s",(int)$user['id'],$hash));
                }
                $this->redirect_notice('account','AinPath Password পরিবর্তন হয়েছে।');
                break;
        }
    }

    private function notifications() {
        $items = get_option(self::OPT_NOTICES, []);
        return is_array($items) ? $items : [];
    }

    private function add_notification($id, $title, $message, $type='info', $version='') {
        $items = $this->notifications();
        foreach ($items as $item) {
            if (!empty($item['id']) && $item['id'] === $id) return;
        }
        array_unshift($items, [
            'id' => sanitize_key($id),
            'title' => sanitize_text_field($title),
            'message' => sanitize_textarea_field($message),
            'type' => sanitize_key($type),
            'version' => sanitize_text_field($version),
            'created_at' => current_time('mysql'),
            'read' => 0,
        ]);
        if (count($items) > 50) $items = array_slice($items, 0, 50);
        update_option(self::OPT_NOTICES, $items, false);
    }

    private function unread_notifications() {
        $n = 0;
        foreach ($this->notifications() as $item) if (empty($item['read'])) $n++;
        return $n;
    }

    private function remote_manifest($force=false) {
        $s = $this->settings();
        $url = trim((string)$s['update_manifest_url']);
        if (!$url) return new WP_Error('no_source', 'No update source');
        if (!$force) {
            $cached = get_transient('ainpath_cc_remote_manifest');
            if (is_array($cached)) return $cached;
        }
        $resp = wp_remote_get($url, ['timeout'=>10, 'headers'=>['Accept'=>'application/json']]);
        if (is_wp_error($resp)) return $resp;
        $code = (int)wp_remote_retrieve_response_code($resp);
        if ($code < 200 || $code >= 300) return new WP_Error('http_error', 'Update source HTTP '.$code);
        $data = json_decode(wp_remote_retrieve_body($resp), true);
        if (!is_array($data) || empty($data['version']) || empty($data['download_url'])) return new WP_Error('bad_manifest', 'Invalid update manifest');
        set_transient('ainpath_cc_remote_manifest', $data, 6 * HOUR_IN_SECONDS);
        update_option('ainpath_cc_last_update_check', current_time('mysql'), false);
        return $data;
    }

    private function check_for_updates($force=false) {
        $manifest = $this->remote_manifest($force);
        if (is_wp_error($manifest)) {
            return ['status'=>$manifest->get_error_code()==='no_source' ? 'no_source' : 'error'];
        }
        $remote = sanitize_text_field($manifest['version']);
        update_option('ainpath_cc_latest_remote_version', $remote, false);
        if (version_compare(self::VERSION, $remote, '<')) {
            $changelog = trim(wp_strip_all_tags($manifest['changelog'] ?? ''));
            $msg = 'AinPath Control Center '.$remote.' পাওয়া গেছে। Admin Panel-এর Update Center থেকে Update Now করুন।';
            if ($changelog) $msg .= ' পরিবর্তন: '.$changelog;
            $s = $this->settings();
            if (!empty($s['panel_update_notifications'])) {
                $this->add_notification('update-'.$remote, 'নতুন AinPath Update', $msg, 'update', $remote);
            }
            $mail_key = 'ainpath_cc_emailed_update_'.$remote;
            if (!empty($s['email_update_notifications']) && empty(get_option($mail_key))) {
                $email = sanitize_email($s['notification_email'] ?: get_option('admin_email'));
                if ($email) {
                    wp_mail($email, 'AinPath Update '.$remote, $msg."

".$this->panel_url('updates'));
                    update_option($mail_key, 1, false);
                }
            }
            return ['status'=>'update','version'=>$remote,'manifest'=>$manifest];
        }
        return ['status'=>'current','version'=>$remote,'manifest'=>$manifest];
    }

    public function scheduled_update_check() {
        $this->check_for_updates(false);
    }

    private function redirect_notice($tab,$msg,$extra=[]) {
        $args = array_merge(['notice'=>$msg], $extra);
        wp_safe_redirect($this->panel_url($tab,$args));
        exit;
    }

    private function render_panel() {
        $modules = $this->modules();
        $settings = $this->settings();
        $tab = sanitize_key($_GET['tab'] ?? 'dashboard');
        $allowed = ['dashboard','sections','import','history','fields','modules','backup','master','settings','updates','notifications','account'];
        if (!in_array($tab,$allowed,true)) $tab='dashboard';

        $title = esc_html($settings['panel_title']);
        $logout = home_url('/ainpath-logout/');
        $unread = $this->unread_notifications();
        $nonce = $this->csrf_token('panel');
        $notice = isset($_GET['notice']) ? sanitize_text_field(wp_unslash($_GET['notice'])) : '';

        echo '<!doctype html><html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.$title.'</title>';
        echo '<link rel="stylesheet" href="'.esc_url(plugins_url('assets/panel.css', __FILE__)).'?v='.self::VERSION.'">';
        echo '</head><body><div class="ap-shell">';
        echo '<aside class="ap-side"><div class="ap-brand">'.$title.'</div><div class="ap-sub">নিজস্ব Admin Panel</div><nav>';
        $nav = [
            'dashboard'=>['ড্যাশবোর্ড','🏠',1],
            'sections'=>['আইন/ধারা','📚',$modules['sections']],
            'import'=>['Smart Import','⚡',$modules['smart_import']],
            'history'=>['Import History','🕘',$modules['history']],
            'fields'=>['Field & Rules','🧩',$modules['fields_rules']],
            'master'=>['Master Validation','✅',$modules['fields_rules']],
            'modules'=>['Modules','🧱',1],
            'backup'=>['Backup/Restore','💾',$modules['backup']],
            'updates'=>['Update Center','⬆️',1],
            'notifications'=>['Notifications','🔔',1],
            'account'=>['Login & Account','🔐',1],
            'settings'=>['Settings','⚙️',1],
        ];
        foreach ($nav as $k=>$n) {
            if (!$n[2]) continue;
            $cls = $tab===$k ? 'active' : '';
            $badge = ($k==='notifications' && $unread) ? '<em class="ap-badge">'.intval($unread).'</em>' : '';
            echo '<a class="'.$cls.'" href="'.esc_url($this->panel_url($k)).'"><span>'.$n[1].'</span>'.$n[0].$badge.'</a>';
        }
        echo '</nav><div class="ap-side-footer"><a href="'.esc_url(home_url('/')).'">সাইট দেখুন</a><a href="'.esc_url($logout).'">লগআউট</a></div></aside>';
        echo '<main class="ap-main"><header class="ap-top"><button class="ap-menu" onclick="document.body.classList.toggle(\'ap-open\')">☰</button><div><strong>'.$title.'</strong><small>Version '.self::VERSION.'</small></div></header><section class="ap-content">';
        if ($notice) echo '<div class="ap-notice">'.esc_html(rawurldecode($notice)).'</div>';

        switch ($tab) {
            case 'dashboard': $this->page_dashboard(); break;
            case 'sections': $this->page_sections($nonce); break;
            case 'import': $this->page_import($nonce); break;
            case 'history': $this->page_history(); break;
            case 'fields': $this->page_fields($nonce); break;
            case 'modules': $this->page_modules($nonce); break;
            case 'backup': $this->page_backup($nonce); break;
            case 'master': $this->page_master($nonce); break;
            case 'updates': $this->page_updates($nonce); break;
            case 'notifications': $this->page_notifications($nonce); break;
            case 'account': $this->page_account($nonce); break;
            case 'settings': $this->page_settings($nonce); break;
        }
        echo '</section></main></div><script src="'.esc_url(plugins_url('assets/panel.js', __FILE__)).'?v='.self::VERSION.'"></script></body></html>';
    }

    private function page_dashboard() {
        $count = wp_count_posts(self::CPT_SECTION);
        global $wpdb;
        $log_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}ainpath_import_logs");
        $last = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}ainpath_import_logs ORDER BY id DESC LIMIT 1", ARRAY_A);
        echo '<h1>ড্যাশবোর্ড</h1><p class="ap-lead">AinPath-এর আইন/ধারা ও Import সিস্টেম এখান থেকে নিয়ন্ত্রণ করুন।</p>';
        $unread = $this->unread_notifications();
        $latest = get_option('ainpath_cc_latest_remote_version', '—');
        echo '<div class="ap-cards"><div class="ap-card"><b>'.intval($count->publish ?? 0).'</b><span>মোট ধারা</span></div><div class="ap-card"><b>'.$log_count.'</b><span>মোট Import</span></div><div class="ap-card"><b>'.intval($unread).'</b><span>নতুন Notification</span></div><div class="ap-card"><b>'.esc_html($latest).'</b><span>সর্বশেষ জানা Version</span></div></div>';
        echo '<div class="ap-panel"><h2>দ্রুত কাজ</h2><div class="ap-actions"><a class="ap-btn primary" href="'.esc_url($this->panel_url('import')).'">Smart Import</a><a class="ap-btn" href="'.esc_url($this->panel_url('sections')).'">আইন/ধারা দেখুন</a><a class="ap-btn" href="'.esc_url($this->panel_url('updates')).'">Update Center</a><a class="ap-btn" href="'.esc_url($this->panel_url('backup')).'">Backup নিন</a></div></div>';
        echo '<div class="ap-panel"><h2>বর্তমান নীতি</h2><p>MCQ Generator এই সংস্করণে ইচ্ছাকৃতভাবে বন্ধ রাখা হয়েছে। পরে আলাদা Module হিসেবে যোগ করা যাবে।</p></div>';
    }

    private function page_sections($nonce) {
        $edit_raw = isset($_GET['edit']) ? sanitize_text_field(wp_unslash($_GET['edit'])) : '';
        $is_new = ($edit_raw === 'new');
        $edit_id = $is_new ? 0 : absint($edit_raw);
        echo '<div class="ap-heading"><div><h1>আইন/ধারা</h1><p>যোগ, সম্পাদনা, খোঁজ ও মুছুন।</p></div><a class="ap-btn primary" href="'.esc_url($this->panel_url('sections',['edit'=>'new'])).'">+ নতুন ধারা</a></div>';
        if ($edit_id || $is_new) {
            $post = $edit_id>0 ? get_post($edit_id) : null;
            $fields = get_option(self::OPT_FIELDS, $this->default_fields());
            $v = function($key,$default='') use ($post) { return $post ? get_post_meta($post->ID,'ap_'.$key,true) : $default; };
            echo '<form method="post" class="ap-panel ap-form"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="save_section"><input type="hidden" name="section_id" value="'.intval($edit_id>0?$edit_id:0).'">';
            echo '<div class="ap-grid"><label>আইন<input name="law" value="'.esc_attr($v('law')).'"></label><label>ধারা<input name="section_no" value="'.esc_attr($v('section_no')).'"></label><label class="span2">শিরোনাম<input name="title" value="'.esc_attr($v('title',$post?$post->post_title:'')).'"></label>';
            foreach ($fields as $key=>$f) {
                if (in_array($key,['law','section_no','title'],true) || empty($f['enabled'])) continue;
                $val = $key==='details' ? ($post?$post->post_content:'') : $v($key);
                echo '<label class="span2">'.esc_html($f['label']).'<textarea name="'.esc_attr($key).'" rows="4">'.esc_textarea($val).'</textarea></label>';
            }
            echo '</div><div class="ap-actions"><button class="ap-btn primary" type="submit">সংরক্ষণ</button><a class="ap-btn" href="'.esc_url($this->panel_url('sections')).'">বাতিল</a></div></form>';
            return;
        }
        $search = sanitize_text_field($_GET['s'] ?? '');
        echo '<form class="ap-search" method="get"><input type="hidden" name="tab" value="sections"><input name="s" placeholder="আইন, ধারা বা শিরোনাম খুঁজুন" value="'.esc_attr($search).'"><button class="ap-btn">খুঁজুন</button></form>';
        $args = ['post_type'=>self::CPT_SECTION,'post_status'=>'publish','posts_per_page'=>50,'orderby'=>'date','order'=>'DESC'];
        if ($search) $args['s']=$search;
        $q = new WP_Query($args);
        echo '<div class="ap-table-wrap"><table class="ap-table"><thead><tr><th>আইন</th><th>ধারা</th><th>শিরোনাম</th><th>কাজ</th></tr></thead><tbody>';
        if (!$q->have_posts()) echo '<tr><td colspan="4">কোনো ধারা পাওয়া যায়নি।</td></tr>';
        while ($q->have_posts()) { $q->the_post(); $id=get_the_ID();
            echo '<tr><td>'.esc_html(get_post_meta($id,'ap_law',true)).'</td><td>'.esc_html(get_post_meta($id,'ap_section_no',true)).'</td><td>'.esc_html(get_post_meta($id,'ap_title',true) ?: get_the_title()).'</td><td><a href="'.esc_url($this->panel_url('sections',['edit'=>$id])).'">Edit</a> <form method="post" style="display:inline" onsubmit="return confirm(\'মুছে ফেলবেন?\')"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="delete_section"><input type="hidden" name="section_id" value="'.$id.'"><button class="ap-link danger" type="submit">Delete</button></form></td></tr>';
        }
        wp_reset_postdata();
        echo '</tbody></table></div>';
    }

    private function page_import($nonce) {
        echo '<h1>Smart Section Importer</h1><p class="ap-lead">সাধারণ বা এলোমেলো লেখা পেস্ট করুন। সিস্টেম ধারা, শিরোনাম ও পরিচিত field নিজে শনাক্ত করে Preview করবে।</p>';
        $preview = get_transient('ainpath_preview_' . $this->current_custom_user_id());
        if (!empty($_GET['preview']) && $preview) {
            $this->render_preview($preview,$nonce);
            return;
        }
        $s = $this->settings();
        echo '<form method="post" enctype="multipart/form-data" class="ap-panel ap-form"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="preview_import">';
        echo '<label>ডিফল্ট আইন (ঐচ্ছিক)<input name="import_default_law" value="'.esc_attr($s['default_law']).'" placeholder="যেমন: দণ্ডবিধি, ১৮৬০"></label>';
        echo '<div class="ap-filebox"><label><strong>TXT ফাইল থেকে পুরো লেখা নিন</strong><input type="file" name="raw_text_file" id="ap-raw-file" accept=".txt,.md,text/plain,text/markdown"></label><small>মোবাইলে Copy/Paste কেটে গেলে এই অপশন ব্যবহার করুন। ফাইল বেছে নিলে পুরো TXT/MD ফাইল সরাসরি Analyze হবে।</small><div id="ap-file-status" class="ap-file-status"></div></div>';
        echo '<div class="ap-or"><span>অথবা</span></div>';
        echo '<label>সব লেখা এখানে পেস্ট করুন<textarea id="ap-raw-text" name="raw_text" rows="20" placeholder="উদাহরণ:\nদণ্ডবিধি\nধারা: ১০৭\nশিরোনাম: প্ররোচনা\nমূল ধারণা: ...\n\n১০৮ - প্ররোচনাকারী\nব্যাখ্যা: ..."></textarea></label>';
        echo '<div id="ap-text-stats" class="ap-text-stats">পেস্ট করা লেখা: ০ অক্ষর</div>';
        echo '<div class="ap-note"><strong>Smart Detect:</strong> [SECTION] লেখা বাধ্যতামূলক নয়। “ধারা: ১০৭”, “১০৭ - শিরোনাম”, “দণ্ডবিধি ১০৭ ...” ধরনের লেখা শনাক্ত করার চেষ্টা করবে। নিশ্চিত না হলে Warning দেখাবে; আইনগত তথ্য অনুমান করে বানাবে না।</div>';
        echo '<button class="ap-btn primary" type="submit">Analyze & Preview</button></form>';
    }

    private function render_preview($preview,$nonce) {
        $records = $preview['records'] ?? [];
        $global = $preview['global_warnings'] ?? [];
        $source_label = !empty($preview['source_name']) ? $preview['source_name'] : 'paste';
        $source_chars = isset($preview['source_chars']) ? (int)$preview['source_chars'] : 0;
        $source_lines = isset($preview['source_lines']) ? (int)$preview['source_lines'] : 0;
        echo '<div class="ap-heading"><div><h2>Import Preview</h2><p>'.count($records).'টি ধারা শনাক্ত হয়েছে। উৎস: '.esc_html($source_label).' · '.number_format_i18n($source_chars).' অক্ষর · '.number_format_i18n($source_lines).' লাইন</p></div><a class="ap-btn" href="'.esc_url($this->panel_url('import')).'">← আবার লিখুন</a></div>';
        foreach ($global as $w) echo '<div class="ap-warning">⚠ '.esc_html($w).'</div>';
        echo '<div class="ap-table-wrap"><table class="ap-table"><thead><tr><th>#</th><th>আইন</th><th>ধারা</th><th>শিরোনাম</th><th>অবস্থা</th></tr></thead><tbody>';
        foreach ($records as $i=>$r) {
            $issues = $r['_issues'] ?? [];
            $status = $issues ? '<span class="badge warn">'.count($issues).' warning</span>' : '<span class="badge ok">OK</span>';
            echo '<tr><td>'.($i+1).'</td><td>'.esc_html($r['law'] ?? '').'</td><td>'.esc_html($r['section_no'] ?? '').'</td><td>'.esc_html($r['title'] ?? '').'</td><td>'.$status;
            if ($issues) echo '<div class="ap-issues">'.esc_html(implode(' | ',$issues)).'</div>';
            echo '</td></tr>';
        }
        echo '</tbody></table></div>';
        if ($records) {
            echo '<form method="post" class="ap-actions"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="confirm_import"><button class="ap-btn primary" type="submit">Import Now</button><a class="ap-btn" href="'.esc_url($this->panel_url('import')).'">Cancel</a></form>';
        }
    }

    private function page_history() {
        global $wpdb;
        $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}ainpath_import_logs ORDER BY id DESC LIMIT 100", ARRAY_A);
        echo '<h1>Import History</h1><div class="ap-table-wrap"><table class="ap-table"><thead><tr><th>সময়</th><th>মোট</th><th>নতুন</th><th>আপডেট</th><th>বাদ</th><th>ত্রুটি</th></tr></thead><tbody>';
        if (!$rows) echo '<tr><td colspan="6">এখনো কোনো Import history নেই।</td></tr>';
        foreach ($rows as $r) echo '<tr><td>'.esc_html($r['created_at']).'</td><td>'.intval($r['total_count']).'</td><td>'.intval($r['inserted_count']).'</td><td>'.intval($r['updated_count']).'</td><td>'.intval($r['skipped_count']).'</td><td>'.intval($r['error_count']).'</td></tr>';
        echo '</tbody></table></div>';
    }

    private function page_fields($nonce) {
        $fields = get_option(self::OPT_FIELDS, $this->default_fields());
        echo '<h1>Field & Rules Manager</h1><p class="ap-lead">কোন শব্দ দেখলে কোন field-এ যাবে, তা এখান থেকে নিয়ন্ত্রণ করুন।</p>';
        echo '<form method="post" class="ap-panel ap-form"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="save_fields"><div class="ap-table-wrap"><table class="ap-table"><thead><tr><th>চালু</th><th>Field</th><th>নাম</th><th>Aliases / চেনার শব্দ</th></tr></thead><tbody>';
        foreach ($fields as $key=>$f) {
            echo '<tr><td><input type="checkbox" name="fields['.esc_attr($key).'][enabled]" value="1" '.checked(!empty($f['enabled']),true,false).'></td><td><code>'.esc_html($key).'</code></td><td><input name="fields['.esc_attr($key).'][label]" value="'.esc_attr($f['label']).'"></td><td><textarea rows="2" name="fields['.esc_attr($key).'][aliases]">'.esc_textarea(implode(', ', $f['aliases'] ?? [])).'</textarea></td></tr>';
        }
        echo '</tbody></table></div><h3>নতুন Custom Field</h3><div class="ap-grid"><label>Field label<input name="new_field_label"></label><label>Key (ঐচ্ছিক)<input name="new_field_key" placeholder="যেমন: ingredients"></label><label class="span2">চেনার শব্দ / aliases<textarea name="new_field_aliases" rows="2" placeholder="কমা দিয়ে লিখুন"></textarea></label></div><button class="ap-btn primary" type="submit">Save Fields & Rules</button></form>';
    }

    private function page_modules($nonce) {
        $m = $this->modules();
        $labels = ['sections'=>'আইন/ধারা Manager','smart_import'=>'Smart Import','history'=>'Import History','fields_rules'=>'Field/Rules & Validation','backup'=>'Backup/Restore','updates'=>'Remote Update Engine'];
        echo '<h1>Module Manager</h1><p class="ap-lead">Core feature চালু/বন্ধ করুন। MCQ পরে আলাদা Module হিসেবে যোগ করা হবে।</p>';
        echo '<form method="post" class="ap-panel ap-form"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="save_modules">';
        foreach ($labels as $k=>$label) echo '<label class="ap-toggle"><input type="checkbox" name="modules['.esc_attr($k).']" value="1" '.checked(!empty($m[$k]),true,false).'><span>'.esc_html($label).'</span></label>';
        echo '<div class="ap-toggle disabled"><input type="checkbox" disabled><span>MCQ Generator — পরে আলাদা Module</span></div><button class="ap-btn primary" type="submit">Save Modules</button></form>';
    }

    private function page_backup($nonce) {
        $backup_url = add_query_arg(['ainpath_action'=>'backup','ap_csrf'=>$this->csrf_token('backup')], home_url('/ainpath-admin/'));
        echo '<h1>Backup & Restore</h1><div class="ap-panel"><h2>Backup</h2><p>সব আইন/ধারা, field/rule, module ও settings একটি JSON file-এ নিন।</p><a class="ap-btn primary" href="'.esc_url($backup_url).'">Download Backup</a></div>';
        echo '<form method="post" enctype="multipart/form-data" class="ap-panel ap-form"><h2>Restore</h2><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="restore_backup"><label>Backup JSON<input type="file" name="backup_file" accept="application/json,.json" required></label><button class="ap-btn danger" type="submit" onclick="return confirm(\'বর্তমান ডেটার সাথে backup merge/update হবে। চালিয়ে যাবেন?\')">Restore Backup</button></form>';
    }

    private function page_master($nonce) {
        $master = get_option(self::OPT_MASTER, []);
        echo '<h1>Master Validation Data</h1><p class="ap-lead">ভবিষ্যতে যাচাইকৃত আইন/ধারা তালিকা দিলে Smart Import ধারা-শিরোনামের mismatch ধরতে পারবে।</p>';
        echo '<form method="post" class="ap-panel ap-form"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="save_master"><label>Master JSON<textarea name="master_json" rows="18" placeholder=\'{"দণ্ডবিধি":{"107":"প্ররোচনা"}}\'>'.esc_textarea($master ? wp_json_encode($master, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT) : '').'</textarea></label><div class="ap-note">Format: { "আইনের নাম": { "ধারা নম্বর": "সঠিক শিরোনাম" } }</div><button class="ap-btn primary" type="submit">Save Master Data</button></form>';
    }

    private function page_updates($nonce) {
        $s = $this->settings();
        $last = get_option('ainpath_cc_last_update_check', '—');
        $latest = get_option('ainpath_cc_latest_remote_version', '—');
        $has_source = !empty($s['update_manifest_url']);
        $available = ($latest !== '—' && version_compare(self::VERSION, $latest, '<'));

        echo '<h1>Update Center</h1><p class="ap-lead">নতুন Version, Notification এবং One-click Update এখান থেকেই নিয়ন্ত্রণ করুন। স্বতন্ত্র AinPath Login থাকলেও Update Center কাজ করবে।</p>';
        echo '<div class="ap-cards"><div class="ap-card"><b>'.esc_html(self::VERSION).'</b><span>বর্তমান Version</span></div><div class="ap-card"><b>'.esc_html($latest).'</b><span>সর্বশেষ জানা Version</span></div><div class="ap-card"><b>'.esc_html($last).'</b><span>শেষ Update Check</span></div></div>';

        if (!$has_source) {
            echo '<div class="ap-warning">⚠ Update Source এখনো সংযুক্ত হয়নি। Settings-এ একটি স্থায়ী Manifest URL দিলে নতুন update এলে এই Panel-এ notification আসবে।</div>';
        } elseif ($available) {
            echo '<div class="ap-update-ready"><strong>নতুন Version '.esc_html($latest).' পাওয়া গেছে।</strong><form method="post" class="ap-actions"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="install_update_now"><button class="ap-btn primary" type="submit" onclick="return confirm(\'নতুন AinPath update এখন ইনস্টল করবেন?\')">Update Now</button><a class="ap-btn" href="'.esc_url($this->panel_url('notifications')).'">Notification দেখুন</a></form></div>';
        } else {
            echo '<div class="ap-note"><strong>Status:</strong> বর্তমানে কোনো নতুন Version শনাক্ত হয়নি।</div>';
        }

        echo '<form method="post" class="ap-panel ap-form"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="check_updates_now"><h2>এখনই Update Check</h2><p>Update Source-এ নতুন Version আছে কি না এখনই পরীক্ষা করুন।</p><button class="ap-btn primary" type="submit">Check Now</button></form>';
        echo '<div class="ap-panel"><h2>Notification ব্যবস্থা</h2><p>সাইটে cron চললে AinPath দিনে দুইবার Update Source পরীক্ষা করবে। নতুন Version পেলে 🔔 Notifications-এ দেখাবে। Email Notification চালু থাকলে ইমেইলও পাঠানোর চেষ্টা করবে।</p></div>';
    }

    private function page_notifications($nonce) {
        $items = $this->notifications();
        echo '<div class="ap-heading"><div><h1>Notifications</h1><p>Update ও গুরুত্বপূর্ণ System message এখানে থাকবে।</p></div>';
        if ($items) echo '<form method="post"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="mark_all_notifications_read"><button class="ap-btn" type="submit">সব পড়া হয়েছে</button></form>';
        echo '</div>';
        if (!$items) {
            echo '<div class="ap-panel"><p>এখন কোনো Notification নেই।</p></div>';
            return;
        }
        echo '<div class="ap-notification-list">';
        foreach ($items as $item) {
            $cls = empty($item['read']) ? ' unread' : '';
            echo '<div class="ap-notification'.$cls.'"><div><strong>'.esc_html($item['title'] ?? 'Notification').'</strong><small>'.esc_html($item['created_at'] ?? '').'</small></div><p>'.esc_html($item['message'] ?? '').'</p>';
            if (!empty($item['version']) && version_compare(self::VERSION, $item['version'], '<')) echo '<a class="ap-btn primary" href="'.esc_url($this->panel_url('updates')).'">Update Center</a>';
            echo '</div>';
        }
        echo '</div>';
    }

    private function page_account($nonce) {
        $u = $this->current_custom_user();
        echo '<h1>Login & Account</h1><p class="ap-lead">AinPath-এর স্বতন্ত্র Login account এখান থেকে নিয়ন্ত্রণ করুন।</p>';
        echo '<div class="ap-panel"><h2>AinPath Login</h2><p><strong>Login URL:</strong><br><code>'.esc_html(home_url('/ainpath-login/')).'</code></p><p>এই account WordPress account থেকে আলাদা। WordPress username/password পরিবর্তন হলেও AinPath Login বদলাবে না, এবং AinPath Password বদলালেও WordPress Password বদলাবে না।</p><div class="ap-actions"><a class="ap-btn" href="'.esc_url(home_url('/ainpath-logout/')).'">লগআউট করে Login Page দেখুন</a></div></div>';
        echo '<div class="ap-panel"><h2>বর্তমান AinPath Account</h2><p><strong>Username:</strong> '.esc_html($u['username'] ?? '').'<br><strong>নাম:</strong> '.esc_html($u['display_name'] ?? '').'<br><strong>Email:</strong> '.esc_html($u['email'] ?? '').'</p></div>';
        echo '<form method="post" class="ap-panel ap-form"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="change_password"><h2>AinPath Password পরিবর্তন</h2><label>বর্তমান Password<input type="password" name="current_password" autocomplete="current-password" required></label><label>নতুন Password<input type="password" name="new_password" autocomplete="new-password" minlength="10" required></label><label>নতুন Password আবার<input type="password" name="confirm_password" autocomplete="new-password" minlength="10" required></label><button class="ap-btn primary" type="submit">Password পরিবর্তন</button></form>';
    }

    private function page_settings($nonce) {
        $s = $this->settings();
        echo '<h1>Settings</h1><p class="ap-lead">AinPath Control Center-এর সাধারণ, Import এবং Update/Notification settings এখান থেকে নিয়ন্ত্রণ করুন।</p>';
        echo '<form method="post" class="ap-panel ap-form"><input type="hidden" name="ap_csrf" value="'.esc_attr($nonce).'"><input type="hidden" name="ainpath_action" value="save_settings"><div class="ap-grid">';
        echo '<label>Panel নাম<input name="panel_title" value="'.esc_attr($s['panel_title']).'"></label><label>ডিফল্ট আইন<input name="default_law" value="'.esc_attr($s['default_law']).'"></label>';
        echo '<label>Duplicate handling<select name="duplicate_mode"><option value="update" '.selected($s['duplicate_mode'],'update',false).'>আগেরটি Update</option><option value="skip" '.selected($s['duplicate_mode'],'skip',false).'>Duplicate Skip</option></select></label>';
        echo '<label class="check"><input type="checkbox" name="auto_title_from_first_line" value="1" '.checked($s['auto_title_from_first_line'],1,false).'>শিরোনাম না থাকলে প্রথম ছোট লাইন থেকে অনুমান</label>';
        echo '<label class="check"><input type="checkbox" name="master_autocorrect" value="1" '.checked($s['master_autocorrect'],1,false).'>Master Data নিশ্চিত হলে শিরোনাম Auto-correct</label>';
        echo '</div><h2>Update & Notification</h2><div class="ap-grid">';
        echo '<label class="span2">Update Manifest URL<input name="update_manifest_url" value="'.esc_attr($s['update_manifest_url']).'" placeholder="https://example.com/ainpath-update.json"><small>একবার স্থায়ী update source যুক্ত হলে ভবিষ্যতে ZIP upload না করে Update Center থেকে Update Now করা যাবে।</small></label>';
        echo '<label>Notification Email<input type="email" name="notification_email" value="'.esc_attr($s['notification_email']).'" placeholder="'.esc_attr(get_option('admin_email')).'"></label>';
        echo '<label class="check"><input type="checkbox" name="panel_update_notifications" value="1" '.checked($s['panel_update_notifications'],1,false).'>নতুন Update এলে Control Center-এ Notification দেখান</label>';
        echo '<label class="check"><input type="checkbox" name="email_update_notifications" value="1" '.checked($s['email_update_notifications'],1,false).'>নতুন Update এলে Email পাঠানোর চেষ্টা করুন</label>';
        echo '<label class="check"><input type="checkbox" name="auto_update_plugin" value="1" '.checked($s['auto_update_plugin'],1,false).'>AinPath update স্বয়ংক্রিয়ভাবে ইনস্টল করুন</label>';
        echo '</div><button class="ap-btn primary" type="submit">Save Settings</button></form>';
        echo '<div class="ap-panel"><h2>একবার সেটআপ, পরে ZIP নয়</h2><p>Update Manifest URL একটি স্থায়ী public source-এ বসানো হলে নতুন Version প্রকাশের সময় AinPath Update Center package নিজে download/install করতে পারবে। আপনার কাজ হবে শুধু Notification দেখে <strong>Update Now</strong> চাপা; Auto Update চালু থাকলে সেটিও লাগবে না।</p></div>';
        echo '<div class="ap-panel"><h2>Update manifest format</h2><pre>{\n  "version": "2.2.1",\n  "download_url": "https://example.com/ainpath-control-center-2.2.1.zip",\n  "homepage": "https://example.com",\n  "requires": "6.0",\n  "tested": "6.8",\n  "changelog": "..."\n}</pre></div>';
    }

    private function parse_smart_text($raw, $default_law='') {
        $raw = trim(str_replace(["\r\n","\r"],"\n",$raw));
        $lines = preg_split('/\n/u',$raw);
        $fields = get_option(self::OPT_FIELDS, $this->default_fields());
        $settings = $this->settings();
        $master = get_option(self::OPT_MASTER, []);
        $current_law = $default_law ?: $settings['default_law'];
        $records = [];
        $current = null;
        $warnings = [];
        $batch_keys = [];

        $flush = function() use (&$current,&$records,&$batch_keys,$master,$settings) {
            if (!$current) return;
            foreach ($current as $k=>$v) if (is_string($v)) $current[$k]=trim($v);
            if (empty($current['law'])) $current['_issues'][]='আইনের নাম পাওয়া যায়নি';
            if (empty($current['section_no'])) $current['_issues'][]='ধারা নম্বর পাওয়া যায়নি';
            if (empty($current['title'])) $current['_issues'][]='শিরোনাম পাওয়া যায়নি';
            $key = mb_strtolower(trim(($current['law'] ?? '').'|'.($current['section_no'] ?? '')),'UTF-8');
            if ($key !== '|') {
                if (isset($batch_keys[$key])) $current['_issues'][]='একই Import-এ duplicate ধারা';
                $batch_keys[$key]=1;
            }
            if (!empty($current['law']) && !empty($current['section_no']) && !empty($master[$current['law']][$current['section_no']])) {
                $correct = $master[$current['law']][$current['section_no']];
                if (!empty($current['title']) && $this->soft_normalize($current['title']) !== $this->soft_normalize($correct)) {
                    if (!empty($settings['master_autocorrect'])) {
                        $current['_issues'][]='Master Data অনুযায়ী শিরোনাম সংশোধন করা হয়েছে';
                        $current['title']=$correct;
                    } else {
                        $current['_issues'][]='Master Data-র শিরোনামের সাথে মিলছে না; প্রস্তাব: '.$correct;
                    }
                }
            }
            if (!empty($current['law']) && !empty($current['section_no'])) {
                $existing = $this->find_existing_section($current['law'],$current['section_no']);
                if ($existing) $current['_issues'][]='Database-এ এই ধারা আগে আছে';
            }
            $records[]=$current; $current=null;
        };

        foreach ($lines as $line) {
            $line = trim($line);
            if ($line==='') continue;

            // Explicit law line.
            if (preg_match('/^(?:আইন|আইনের নাম|law|act|code)\s*[:：\-]?\s*(.+)$/iu',$line,$m)) {
                $current_law = trim($m[1]);
                if ($current) $current['law']=$current_law;
                continue;
            }
            // Standalone law heading.
            if (!$current && mb_strlen($line,'UTF-8') < 90 && preg_match('/(?:আইন|বিধি|দণ্ডবিধি|কার্যবিধি|Act|Code)(?:\s*,?\s*\d{4}|\s*[০-৯]{4})?$/iu',$line)) {
                $current_law = $line; continue;
            }

            $section_no=''; $tail=''; $law_from_line='';
            if (preg_match('/^(?:ধারা|section|sec\.?|সেকশন)\s*[:：\-]?\s*([০-৯0-9]+(?:\s*\([^\)]+\))?)\s*(?:[:：\-–—]\s*(.*))?$/iu',$line,$m)) {
                $section_no=$m[1]; $tail=trim($m[2] ?? '');
            } elseif (preg_match('/^(.{2,60}?(?:আইন|বিধি|দণ্ডবিধি|কার্যবিধি|Act|Code))\s+(?:ধারা\s*)?([০-৯0-9]+(?:\s*\([^\)]+\))?)\s*(?:[:：\-–—]?\s*(.*))$/iu',$line,$m)) {
                $law_from_line=trim($m[1]); $section_no=$m[2]; $tail=trim($m[3] ?? '');
            } elseif (preg_match('/^([০-৯0-9]+(?:\s*\([^\)]+\))?)\s*[\.\)\-–—:]\s*(.{2,120})$/u',$line,$m)) {
                $section_no=$m[1]; $tail=trim($m[2]);
            }

            if ($section_no!=='') {
                $flush();
                if ($law_from_line) $current_law=$law_from_line;
                $current=['law'=>$current_law,'section_no'=>$this->normalize_digits($section_no),'title'=>'','concept'=>'','explanation'=>'','police_example'=>'','punishment'=>'','time_limit'=>'','revision'=>'','amendment'=>'','details'=>'','_issues'=>[]];
                if ($tail!=='') $current['title']=$tail;
                continue;
            }

            if (!$current) {
                $warnings[]='ধারা শুরু হওয়ার আগে একটি লাইন বাদ গেছে: '.$line;
                continue;
            }

            $matched=false;
            foreach ($fields as $key=>$f) {
                if (empty($f['enabled']) || $key==='section_no') continue;
                foreach (($f['aliases'] ?? []) as $alias) {
                    $a = preg_quote(trim($alias),'/');
                    if (preg_match('/^'.$a.'\s*[:：\-]?\s*(.*)$/iu',$line,$m)) {
                        $val=trim($m[1]);
                        if ($key==='law') { $current['law']=$val; $current_law=$val; }
                        elseif ($key==='title') $current['title']=$val;
                        else {
                            if (!isset($current[$key])) $current[$key]='';
                            $current[$key] .= ($current[$key]!==''?"\n":'') . $val;
                        }
                        $matched=true; break 2;
                    }
                }
            }
            if ($matched) continue;

            if (empty($current['title']) && !empty($settings['auto_title_from_first_line']) && mb_strlen($line,'UTF-8') <= 100) {
                $current['title']=$line;
            } else {
                $current['details'] .= ($current['details']!==''?"\n":'') . $line;
            }
        }
        $flush();
        if (!$records && $raw!=='') $warnings[]='কোনো ধারা শনাক্ত করা যায়নি। “ধারা: ১০৭” বা “১০৭ - শিরোনাম” ধরনের ধারা-চিহ্ন দিন।';
        return ['records'=>$records,'global_warnings'=>array_values(array_unique($warnings))];
    }

    private function import_records($records, $from_backup=false) {
        $s = $this->settings();
        $inserted=$updated=$skipped=$errors=0;
        foreach ($records as $r) {
            $law = sanitize_text_field($r['law'] ?? '');
            $no = sanitize_text_field($r['section_no'] ?? '');
            if (!$no) { $errors++; continue; }
            $existing = $this->find_existing_section($law,$no);
            if ($existing && $s['duplicate_mode']==='skip' && !$from_backup) { $skipped++; continue; }
            $title = sanitize_text_field($r['title'] ?? '');
            $postarr = ['post_type'=>self::CPT_SECTION,'post_status'=>'publish','post_title'=>$title ?: ('ধারা '.$no),'post_content'=>wp_kses_post($r['details'] ?? '')];
            if ($existing) $postarr['ID']=$existing;
            $id=wp_insert_post($postarr,true);
            if (is_wp_error($id)) { $errors++; continue; }
            update_post_meta($id,'ap_law',$law); update_post_meta($id,'ap_section_no',$this->normalize_digits($no)); update_post_meta($id,'ap_title',$title);
            foreach ($r as $key=>$val) {
                if ($key[0]==='_' || in_array($key,['law','section_no','title','details'],true)) continue;
                if (is_scalar($val)) update_post_meta($id,'ap_'.$key,wp_kses_post((string)$val));
            }
            if ($existing) $updated++; else $inserted++;
        }
        $this->log_import(count($records),$inserted,$updated,$skipped,$errors);
        return compact('inserted','updated','skipped','errors');
    }

    private function find_existing_section($law,$section_no) {
        $q = new WP_Query([
            'post_type'=>self::CPT_SECTION,'post_status'=>'any','posts_per_page'=>1,'fields'=>'ids',
            'meta_query'=>[
                'relation'=>'AND',
                ['key'=>'ap_law','value'=>$law,'compare'=>'='],
                ['key'=>'ap_section_no','value'=>$this->normalize_digits($section_no),'compare'=>'=']
            ]
        ]);
        return !empty($q->posts[0]) ? (int)$q->posts[0] : 0;
    }

    private function normalize_digits($s) {
        return strtr(trim((string)$s), ['০'=>'0','১'=>'1','২'=>'2','৩'=>'3','৪'=>'4','৫'=>'5','৬'=>'6','৭'=>'7','৮'=>'8','৯'=>'9']);
    }

    private function soft_normalize($s) {
        $s = mb_strtolower(trim((string)$s),'UTF-8');
        $s = preg_replace('/[\s\p{P}\p{S}]+/u','',$s);
        return $s;
    }

    private function log_import($total,$inserted,$updated,$skipped,$errors) {
        global $wpdb;
        $wpdb->insert($wpdb->prefix.'ainpath_import_logs',[
            'created_at'=>current_time('mysql'),'user_id'=>$this->current_custom_user_id(),'source_name'=>'Smart Import',
            'total_count'=>$total,'inserted_count'=>$inserted,'updated_count'=>$updated,'skipped_count'=>$skipped,'error_count'=>$errors,
            'summary'=>wp_json_encode(compact('total','inserted','updated','skipped','errors'),JSON_UNESCAPED_UNICODE)
        ],['%s','%d','%s','%d','%d','%d','%d','%d','%s']);
    }

    private function export_sections() {
        $q = new WP_Query(['post_type'=>self::CPT_SECTION,'post_status'=>'publish','posts_per_page'=>-1,'fields'=>'ids']);
        $out=[];
        foreach ($q->posts as $id) {
            $row=['law'=>get_post_meta($id,'ap_law',true),'section_no'=>get_post_meta($id,'ap_section_no',true),'title'=>get_post_meta($id,'ap_title',true),'details'=>get_post_field('post_content',$id)];
            $fields=get_option(self::OPT_FIELDS,$this->default_fields());
            foreach ($fields as $key=>$f) if (!in_array($key,['law','section_no','title','details'],true)) $row[$key]=get_post_meta($id,'ap_'.$key,true);
            $out[]=$row;
        }
        return $out;
    }

    public function check_remote_update($transient) {
        if (empty($transient->checked)) return $transient;
        $data = $this->remote_manifest(false);
        if (is_wp_error($data)) return $transient;
        if (version_compare(self::VERSION, $data['version'], '<')) {
            $plugin = plugin_basename(__FILE__);
            $obj = new stdClass();
            $obj->slug = 'ainpath-control-center';
            $obj->plugin = $plugin;
            $obj->new_version = $data['version'];
            $obj->url = $data['homepage'] ?? '';
            $obj->package = $data['download_url'];
            $obj->requires = $data['requires'] ?? '6.0';
            $obj->tested = $data['tested'] ?? '';
            $transient->response[$plugin] = $obj;
        }
        return $transient;
    }

    public function plugin_info($res,$action,$args) {
        if ($action!=='plugin_information' || empty($args->slug) || $args->slug!=='ainpath-control-center') return $res;
        $data = $this->remote_manifest(false);
        if (is_wp_error($data)) return $res;
        $obj = new stdClass();
        $obj->name = 'AinPath Control Center';
        $obj->slug = 'ainpath-control-center';
        $obj->version = $data['version'] ?? self::VERSION;
        $obj->author = 'AinPath';
        $obj->homepage = $data['homepage'] ?? '';
        $obj->requires = $data['requires'] ?? '6.0';
        $obj->tested = $data['tested'] ?? '';
        $obj->download_link = $data['download_url'] ?? '';
        $obj->sections = [
            'description' => 'AinPath Control Center',
            'changelog' => wp_kses_post($data['changelog'] ?? ''),
        ];
        return $obj;
    }

    public function maybe_auto_update($update, $item) {
        if (empty($item->plugin) || $item->plugin !== plugin_basename(__FILE__)) return $update;
        $s = $this->settings();
        return !empty($s['auto_update_plugin']) ? true : $update;
    }

}

register_activation_hook(__FILE__, ['AinPath_Control_Center','activate']);
register_deactivation_hook(__FILE__, ['AinPath_Control_Center','deactivate']);
AinPath_Control_Center::instance();
